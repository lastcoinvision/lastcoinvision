Development moved to https://gitlab.com/blacknet-ninja

https://lastcoin.org/ aims to continue on Lastcoin chain.
